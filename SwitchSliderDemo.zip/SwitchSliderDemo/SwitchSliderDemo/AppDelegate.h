//
//  AppDelegate.h
//  SwitchSliderDemo
//
//  Created by MAC OS on 16/5/23.
//  Copyright © 2016年 niaoren information technology co., LTD. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

